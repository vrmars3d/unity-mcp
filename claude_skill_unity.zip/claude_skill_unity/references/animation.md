# Unity - Animation

**Pages:** 11

---

## Unity - Manual: Add an Animation Event

**URL:** https://docs.unity3d.com/Manual/script-AnimationWindowEvent.html

---

## Unity - Manual: Animation clips

**URL:** https://docs.unity3d.com/Manual/AnimationClips.html

---

## Unity - Manual: Animation

**URL:** https://docs.unity3d.com/Manual/AnimationSection.html

---

## Unity - Manual: Animator component

**URL:** https://docs.unity3d.com/Manual/class-Animator.html

---

## Unity - Manual: Animator Controller

**URL:** https://docs.unity3d.com/Manual/class-AnimatorController.html

---

## Unity - Manual: Animator Controller Asset

**URL:** https://docs.unity3d.com/Manual/Animator.html

---

## Unity - Manual: Animator Override Controller

**URL:** https://docs.unity3d.com/Manual/AnimatorOverrideController.html

---

## Unity - Manual: Animator Window

**URL:** https://docs.unity3d.com/Manual/AnimatorWindow.html

---

## Unity - Manual: Create an Animator Controller

**URL:** https://docs.unity3d.com/Manual/AnimatorControllerCreation.html

---

## Unity - Manual: Loop optimization on Animation clips

**URL:** https://docs.unity3d.com/Manual/LoopingAnimationClips.html

---

## Unity - Manual: Timeline

**URL:** https://docs.unity3d.com/Manual/com.unity.timeline.html

---
